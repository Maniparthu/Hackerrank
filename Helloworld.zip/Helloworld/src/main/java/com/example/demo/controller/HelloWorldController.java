package com.example.demo.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.CatalogItem;

@RestController
@RequestMapping("/Catalog")
public class HelloWorldController {
	
	@RequestMapping("/{UserId}")
	public List<CatalogItem> getCatalog(@PathVariable("UserId")  String UserId){
		String name;
		String company;
		return Collections.singletonList(
				new CatalogItem(name="maniparthu",company="CTS")
				);
	}
}
 